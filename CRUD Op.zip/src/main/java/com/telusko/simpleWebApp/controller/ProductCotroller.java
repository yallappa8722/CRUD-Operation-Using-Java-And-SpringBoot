package com.telusko.simpleWebApp.controller;

import com.telusko.simpleWebApp.Model.Product;
import com.telusko.simpleWebApp.service.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/")
public class ProductCotroller {

    @Autowired
    private ProductService service;

    @GetMapping("/items/{prodId}")
    public Product getProductById(@PathVariable int prodId) {
        return service.getProductById(prodId);
    }

    @GetMapping("/items")
    public List<Product> getAllProducts() {
        return service.getProducts();
    }

    @PostMapping("/items")
    public  void addProduct(@RequestBody Product prod){
        System.out.println(prod);
        service.addProduct(prod);
    }
    @PutMapping("/items/{id}")
    public Product updateProductById(@PathVariable int id, @RequestBody Product prod) {
        System.out.println("Updating product with ID: " + id);
        return service.updateById(id, prod);
    }

    @DeleteMapping("/items/{prodId}")
    public void deleteProduct(@PathVariable int prodId){
        service.deleteProduct(prodId);
    }

    @DeleteMapping("/items")
    public void deleteAll(){
        System.out.println("All Data Deleted Successfully..!");
        service.deleteAll();
    }
}
